#divide fun
def div(a,b):
    return (a//b)