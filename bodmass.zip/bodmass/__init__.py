from bodmass.a import add
from bodmass.s import sub
from bodmass.m import mul
from bodmass.d import div
