#add fun
def add(a,b):
    return a+b